package PartA;
/**
* <The class Prog01_aOrderedList manages a list of cars from the 'AORDEREDLIST' class and performs the operation like adding cars, removing cars, and handling the input and output files containing car information. 
* The methods in the class are the 'main(String[]args) is where the program execution starts where it will inut/ output with user handles and add and remove cars in this method. The GetInputFile(String UserPrompt method handles input file operations. It prompts the user to enter an input filename, checks if the file exists, and returns a Scanner object to read from the file. If the file does not exist and the user chooses not to retry, it throws a FileNotFoundException.
* The GetOutputFile(String UserPrompt) method handles output file operations. It prompts the user to enter an output filename, creates a PrintWriter object to write to the file, and returns this object. If there are issues creating the PrintWriter, it prompts the user to retry or cancel. 
* The class also depends on the 'AORDEREDLIST' class to manage the order list of the carsm where it also uttilizes the Java I.O classes. 
* The 'main' method keeps thr program fly by initalizing the neccesay object reading the input/outout fie and managing the list of cars and handling exception. 
* The overall class serves the entering point and controller for the program, coordinating interactions between user, input/output files and list of cars.   >
*
* CSC 1351 Programming Project No 1
7
* Section 2
*
* @author Richard Le
* @since March 17, 2024
*
*/

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;



public class Prog01_aOrderedList {
	/*<The method read input from a file, processes commands to add or remove 'Car; objects from an ordered list from 'aOrderList' and uses user for file input and output and handles exception related to file operation. 
	 * Initalizes the scanner in, AORDEREDLIST aOrderedList, and Scanner filecar. Then during it process it enters a while loop that continues as long as there are lines to read from the input file (filecar), it then reads each line from the input file and splits it into parts using comma.
	 * If the first part of the line (accessed using parts[0]) is "A" (case insensitive), it indicates an "Add" operation. It takes out  the make, year, and price information from the remaining parts of the line.
	 * Creates a new Car object (newCar) using the extracted information. Adds the new Car object to the aOrderedList using the add method. If the first part of the line is "D" (case insensitive), it indicates a "Delete" operation. It then repeats the same as adding a line by taking out the make and year information.
	 * It then calls the GetCarIndex method of aOrderedList to find the index of the Car object with the specified make and year.
	 * If a matching Car object is found (index is not -1), it removes the Car object from aOrderedList using the remove method.  >
	 * CSC 1351 Programing Project <1>
	 * Section 2 
	 * 
	 * @Richard Le
	 * @March 17, 2024
	 * 
	 * 
	 * Methodname: main
	 * Parameter: String []
	 * return: doesn't have a return type.
	 */
		public static void main(String[] args) throws FileNotFoundException {
		
			AORDEREDLIST aOrderedList = new AORDEREDLIST();
			Scanner in = new Scanner (System.in);
			Scanner filecar =  GetInputFile("Enter input filename: ");
		
			
			while (filecar.hasNextLine()) {
				String line = filecar.nextLine();
				String [] parts = line.split(",");
				
			if(parts[0].equalsIgnoreCase("A")) {
				
				String make = parts[1];
				int year = Integer.parseInt(parts[2]);
				int price = Integer.parseInt(parts[3]);
				Car newCar = new Car(make, year, price);
				aOrderedList.add(newCar);
			}
			else if(parts[0].equalsIgnoreCase("D")) {
					String make = parts[1];
	                int year = Integer.parseInt(parts[2]);
	                int carToRemove = aOrderedList.GetCarIndex(make, year);	             
	                if(carToRemove != -1) {
	                	aOrderedList.remove(carToRemove);	               	
	                }             
			}
		}	
			
		System.out.println(aOrderedList);
		System.out.println("Enter a output file name: ");	
		String filename = in.nextLine();				
		try {
		    PrintWriter writer = GetOutputFile(filename);
		    if (writer != null) {
		        writer.println("Numbers of cars: " + aOrderedList.size());
		        writer.println();
		        // Other code to write car details
		        for( int i = 0; i < aOrderedList.size(); i++) {
					Comparable compare = aOrderedList.get(i);
					Car car = (Car) compare;
					writer.println("Make: " + car.getMake());
					writer.println("Year: " + car.getYear());
					writer.println("Price: " + car.getPrice());
					writer.println();
		        }
		        writer.close();
		    } else {
		        System.out.println("Error creating PrintWriter. Writer is null.");
		    }
		} catch (FileNotFoundException e) {
		    System.out.println("FileNotFoundException: " + e.getMessage());
		    e.printStackTrace(); // Print the stack trace for detailed error information
		};

	}
		/*<The GetInputFile(String UserPrompt) throws FileNotFoundException method has parameter  "String UserPrompt" which represents the user prompt message. 
		 * It then create 'Scanner' object 'scan' read the input from console. Then inside the 'while(true)' loop it prints the question askinf for the input filename. Then read the filename input from the user using scan.nextLine() and store it in the Filename variable.
		 * It then creates a File of filecar using the input filename. If the files exists, it create and return a new 'Scanner; object to read from file ('return new Scanner(filecar)'.
		 * If file doesn't exist it print the line System.out.println("File does not exist" + Filename +" Would you like to enter a new filename? <Y/N>"), if the user response contains "y" it continue the loop to the prompt for a new filename. Then if the user response isn't "y" or uses "n" it throw a 'FileNotFoundException' with the message .Cancelled'.  >
		 * CSC 1351 Programing Project <1>
		 * Section 2 
		 * 
		 * @Richard Le
		 * @March 17, 2024
		 * 
		 * 
		 * Methodname: GetInputFile
		 * Parameter: String UserPrompt
		 * return: returns new Scanner(filecar) if it exist if it doesn't then it throws a filenotfound exception. 
		 */
		public static Scanner GetInputFile(String UserPrompt) throws FileNotFoundException {
		    
			Scanner scan = new Scanner(System.in);
		    String Filename;
		    		    
		    while(true) {
		    	System.out.println(UserPrompt);		  	
		    	Filename = scan.nextLine();
		    	File filecar = new File(Filename);
		    	
		    	if(filecar.exists()) {
		    		return new Scanner(filecar)
		    		;
		    	}
		    	else{
			    	System.out.println("File does not exist" + Filename +" Would you like to enter a new filename? <Y/N>");
			    	String answer = scan.nextLine().toLowerCase();	
			    	
			    	if(answer.contains("y")) {
			    		continue;
			    	}
			    	else {
			    		throw new FileNotFoundException("Cancelled");
			    	}
		    	}		   
		    }
		}
		/*<The GetOutputFile(String UserPrompt) throws FileNotFoundException method is used to create a 'Printwriter' obect for writing output to a file. Where it takes a 'String UserPrompt' parameter that represent the prompt message to ask the user for output filename. The method will throw a 'FileNotFoundException' if there issues creating the Printwriter.
		 * The method first initalizes the Scanner scan = new Scanner, PrintWriter writer = null and the boolean value = false. The while loop continues until the value becomes true and inside the loop there is a try and catch blocks.
		 * In the try block it read the UserPrompt and stores it on String line and Create a new 'PrintWriter' object writer with the filname. The value is then true and exist loop if PrintWriter is created.
		 * The catch, catches if FileNotFoundExceptioon occurs and display "Error creating PrintWriter. Would you like to enter a new filename? <Y/N> ". It will then read the user input deciding whethher it will retry typing "y" or cancel it typing it 'n'.
		 * If "y" is not chosen it throws e and if it is the loop will continues. Finally the method will return a valid " PrintWriter" object created, it return the 'PrintWriter" object. >
		 * CSC 1351 Programing Project <1>
		 * Section 2 
		 * 
		 * @Richard Le
		 * @March 17, 2024
		 * 
		 * methodName:GetOutputFile
		 * Parameter: String UserPrompt
		 * returns:
		 */
		public static PrintWriter GetOutputFile(String UserPrompt) throws FileNotFoundException {
	        Scanner scan = new Scanner(System.in);
	        PrintWriter writer = null; 
	        boolean value = false;
	        
	        while(!value){
	        
	        try{	
	        	String line = UserPrompt;	     	            
	             writer = new PrintWriter(line);            
	             value = true; 	             
	            }		
	            catch (FileNotFoundException e){
	                    System.out.println("Error creating PrintWriter. Would you like to enter a new filename? <Y/N> ");   	    	       
	    	            String input = scan.nextLine().toLowerCase();  	            
	    	    if (!input.equals("y")) 
	    	    {
	    	    	throw e;
	    	    }
	          }           	            
	       }	          	      
	       return writer;     
	   }
	}


