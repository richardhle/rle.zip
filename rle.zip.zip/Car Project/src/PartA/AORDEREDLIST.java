package PartA;
/**
* <The class AORDEREDLIST manages an ordered list of Car objects and provides methods to manipulate this list, including adding, removing, iterating, and searching for elements.
* The attributes of 'SIZEINCREMENTS' stays constant defining the size. 'oList' is the array storing the comaprable objects from the 'Car' objects. 'listSize' is the capacity of the list, 'numObjects' is number of objects currently in the list, and 'curr' is the index of the current element being accessed through iterator methods.
* The constructor AORDEREDLIST() initializes the ordered list with defult capacity from the SIZEINCREMENTS. Method 'add(Comparable<?> newObjects) add new car object to order list. The toString() method is a string representation of  the entire list of "Car' objects.
* The size() methods retuns number of objects currently in the orderedlist. The get(int index) method r get the 'Comparable' object at the specific index. The isEmpty() method check is orderedlist is emptyybt comparing number of objects. The reset() method resets the whole program. 
* The next() methodget the next element in the ordered list uisng the iterator patter. The hasNext() method checks if tehre is aother element in the iteration sequence. The GetCarIndex(String make, int year) method searches for 'Car; object in the ordered list based on it make and year. 
* The class depennds on the "Car" class fir redefining the 'Car' objects. Overall it provides the function to manage a orderedlist of 'Car' objects, which includes adding, removing, iterating and searching.  >
*
* CSC 1351 Programming Project No 1
7
* Section 2
*
* @author Richard Le
* @since March 17, 2024
*
*/

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Scanner;

public class AORDEREDLIST {

	private final int SIZEINCREMENTS = 20;	
	private Comparable[] oList; //increasing ordered list 
	private int listSize; //the ordered list
	private int numObjects; //number of objects in the ordered list
	private int curr; //index of current element accessed via
	 //iterator methods


	public AORDEREDLIST() {
		this.numObjects = 0;
		this.listSize = SIZEINCREMENTS;
		this.oList = new Car[SIZEINCREMENTS];
		this.curr = -1;
		
	}
	
	/*/
	 * <The method add manages the order list of "Car" Objects. The method ensure the capacity of the list by seeing if the current number of objects "numObjects" is equal to the list capacity of "listSize" , and 
	 * if it was fulll it would create a increased capacity "SIZEINCREMENTS" greater than it current capacity and copies the existing elements into a new array. The method will also find the index , where it initalizes an indez variable = 0
	 * and it enters in the while loop that iterates until the index is less than "numObjects" and the comparison of "oList' and 'newObject ' is less than 0. The loop find correct index where object should be inserted based on he ordered define in compareTo method. 
	 * This method also shift elements to make space for the new objects and starts from lst occupied index of (numObjects - 1) and moves backward shifting the elements one postion to the right until reaching the insertion index.
	 * It then insert new Object, casts the 'newObject' to type 'Car' since list deals with the 'Car' objects, then enter the new 'Car' object at the determined insetion index in the 'oList' array and increments count of "numObjects" in list. >
	 * CSC 1351 Programing Project <1>
	 * Section 2 
	 * 
	 * @Richard Le
	 * @March 17, 2024
	 *  *methodname: add
	 * Parameter: Comparable <?> newObject
	 * return: dsoesn't return anything
	 */
	public void add(Comparable<?> newObject) {
	    if (numObjects == listSize) {
	        Car[] newArray = (Car[]) Arrays.copyOf(oList, listSize + SIZEINCREMENTS);
	        oList = newArray;
	        listSize += SIZEINCREMENTS;
	    }

	    int index = 0;
	    while (index < numObjects && oList[index].compareTo(newObject) < 0) {
	        index++;
	    }

	    // Shift elements to make space for newObject
	    for (int i = numObjects - 1; i >= index; i--) {
	        oList[i + 1] = oList[i];
	    }

	    // Cast newObject to Car since we are dealing with Car objects
	    Car carObject = (Car) newObject;
	    oList[index] = carObject;
	    numObjects++;
	}
	/*
	 * <The String toString() is overriding the toString method from the superclass. It first starts being initalizing the result =" " and itteratre through the element of 'oList' array using the 'for' loop which runs from ' i = 0' to 'numObjects -1'.
	 * If 'i' is less than 0 it means it not the first element and equals " , " to separate the previous elements from current one. Then add "[" to start a new element representation.
	 * Then it adds thre string representing the 'Car' object at index 'i' in 'oList' and finally add "]" to end the element string represenation.
	 * It then returns 'result' that represents the entire list of 'Car' objects from like car1, car2 amd etc.  >
	 * CSC 1351 Programing Project <1>
	 * Section 2 
	 * 
	 * @Richard Le
	 * @March 17, 2024
	 * 
	 * methodname: toString 
	 * Parameter: None
	 * returns: It returns the Strings of make, year, and model in brackets and commas splitting between each String or int for ex. " [Make: Volvo, Year: 1963, Price: 16100]   
	 */
	@Override
	public String toString() {
		
		String result = "";
		for (int i = 0; i < numObjects; i++) {
			if(i > 0) {
				result += " , ";
			}
			result += "["; 
			result += oList[i].toString();
			result += "]";
		}
		return result;
	}
	
	/*<The method int size() simply just returns the value of the 'numObjects' variable. Which return an integer value of the 'numObjects'.>
	 * CSC 1351 Programing Project <1>
	 * Section 2 
	 * 
	 * @Richard Le
	 * @March 17, 2024
	 * 
	 * methodname: Size 
	 * paramete: none
	 * returns: returns the numObjets which returns the number of elements in the list.
	 */
	public int size() {
		return numObjects;
	}
	
	/*<The method Comparable<?> get(int index) , retrieves an element from thr 'AORDEREDLIST' object and used 'index' from parameter to access the element firectly from the array of 'oList'.
	 * Then it returns a 'Comparable' object from element stored at the specific index in 'AORDEREDLST'. The 'Comparable<?>' indicates method can return any object that implements a "Comparable' interface.>
	 * CSC 1351 Programing Project <1>
	 * Section 2 
	 * 
	 * @Richard Le
	 * @March 17, 2024
	 * 
	 * 
	 * methodname: Car get
	 * Parameter: int index
	 * returns: returns the elements in the specified position in the list 
	 */
	public Comparable<?> get(int index) {
		return oList[index];
	}
	
	/*<The method boolean isEmpty() check if the 'numObjects' in the 'AORDEREDLIST' = 0. If it equald 0 it mean the list is empty and returns true, whereas if it is greater than 0 it returns false. >
	 * CSC 1351 Programing Project <1>
	 * Section 2 
	 * 
	 * @Richard Le
	 * @March 17, 2024
	 * 
	 * methodname: isEmpty
	 * Parameter: none
	 * returns numObjects if its = 0 
	 */
	public boolean isEmpty() {
		return numObjects == 0;
	}
	
	/*<The remove(int index) method specifies the 'int index' that needs to be removed. It will check if the specified index is valid for removal, ensuring that the index is not negative and doesn't exceed 'numObjects' list.
	 * If the index is valid, the method proceed to remove the Car object at that index. it shifts the elements in the list starting from the 'index' to 'numObjects -1' to the left by one postion, meaning it effectively ovewrutes the Car object at the specified index with the Car object at the next index.
	 * After all the elements are shifted the last element in the list 'oList[numObjects -1]'is set to 'null' and then finally decrement the 'numObjects' variable reflect that one Car object has been removed. The purpose for the method is to remove the Car object from the ordered list. >
	 * CSC 1351 Programing Project <1>
	 * Section 2 
	 * 
	 * @Richard Le
	 * @March 17, 2024
	 * 
	 * methodname: remove 
	 * parameter: int index 
	 * returns: removes an element from the specified postion in the list, which is connected to the main method. 
	 */
	public void remove(int index) {
	
		if (index < 0 || index >= numObjects) {
			return;
		}
		for (int i = index; i < numObjects - 1; i++ ) {
			oList[i] = oList[i + 1];
		}
		oList[numObjects - 1] = null;
		numObjects --;
	}
	
	/*<The method void reset() setss the value of 'curr' to 0 and the purpose of that it to reset the state of the 'AORDEREDLIST' object. 
	 * Setting the 'curr' to 0 the list will successfully reet its iteration postion to the beginning.>
	 * CSC 1351 Programing Project <1>
	 * Section 2 
	 * 
	 * @Richard Le
	 * @March 17, 2024
	 * 
	 * methodname: reset
	 * parameter: none
	 * returns: curr = 0, meaning it resets the whole program
	 */
	void reset() {
		curr = 0; // resets to the  beginning 
	}
	
	/*<the method Comparable next() retrieves the next element in the ordered list. It uses the 'numObjects' as an index to accesss the elements in the list, and after it return the element
	 * it increments the 'numObjects' by 1, which moes 'cursor' or iteration postion to next possible element in the list. >
	 * CSC 1351 Programing Project <1>
	 * Section 2 
	 * 
	 * @Richard Le
	 * @March 17, 2024
	 * 
	 * methodname: Comparable next
	 * param
	 * return
	 */
	public Comparable next() {
		return oList[numObjects++];
	}
	
	/*<The boolean hasNext() method check if there is another element in the iteration sequence. Where it compares the current postion 'curr' in sequence to the total number of objects in "numObjects" in the data. 
	 * It also chekc if the current postion is not less than 0, which make sure it remain in bound.>
	 * CSC 1351 Programing Project <1>
	 * Section 2 
	 * 
	 * @Richard Le
	 * @March 17, 2024
	 * 
	 * methodname: hasNext
	 * Parameter: none
	 * 
	 */
	boolean hasNext() {
		
		return curr < numObjects && curr >= 0;
	}
	
	/*<The GetCarIndex(String make, int year) method, has the parameter 'String make' which represent the make of car searched for and 'int year' represents the year of car being searched for.
	 * The method returns 'int' which is index of the car object in the ordered list if it found or -1 if the car objec with the specefic make and yearis not found in list.
	 * The method iteratee through Car objects in the 'oList', and for each car it check if the make matches the specefic make parameter and year matches specefic year parameter. If the Car object with matching and make is found the method returns 'i'.
	 * If there are no matching it will return -1.  >
	 * CSC 1351 Programing Project <1>
	 * Section 2 
	 * 
	 * @Richard Le
	 * @March 17, 2024
	 * 
	 * methodname: GetCarIndex
	 * Parameter: String make, int year
	 * returns 
	 */
	public int GetCarIndex(String make , int year ) {
		
		for ( int i = 0; i < numObjects; i++) {
			Car car = (Car)oList[i];	
			if(car.getMake().equals(make) && car.getYear() == year) {
				return i;
			}			
		}
		return -1;		 
	}
	
}	
	



