package PartA;
/**
* <The class name is Car and is the basic model for car object. Public class of car implements a comparable of Car because it means "Car" class is declaring that it implements the 'Comparable' interface with a generic type of parameter of 'Car'. Then there are instance variable of "make" which represent the model of the car(example is Ford, or BMW),
*  instance of "year" which represents the year of the car(ex. 2000 and 1994 ), and instance of  "price" represents the cost of the car.(ex.32100 and 41500 ). Then there is the Constructor "Car" that initalizes a new "Car" Object. Then there are the methods of getMake() which returns the brand of the car as a string, getYear()returns the year of the cars as an int, and the getPrice() returns the price of a car as an int.
*  Then there the comparable implements of the compareTo(Car other) method compares two cars based on their make and model it. The method is used to determineed the order of car list, such that returning the make.compareTo will put the order in alphabetical order and return Intger.compare will be the years in numerical oreder if the make model equals the same values. 
*   Then lastly there the toString method, the toString() method returns the String representation of the "Car" object which returns the output ofthe line of the Make, year and model, for example it would return " Make: Ford, Year: 2016, Price: 4200". >
*
* CSC 1351 Programming Project No 1
7
* Section 2
*
* @author Richard Le
* @since March 17, 2024
*
*/

public class Car implements Comparable<Car> {
	
		private String make;
		private int year;
		private int price;
		/*<Ininitalizes the variables  >
		 * CSC 1351 Programing Project <1>
		 * Section 2 
		 * 
		 * @Richard Le
		 * @March 17, 2024
		 * 
		 * 
		 * Methodname: Car
		 * Parameter: String make, int year, int price
		 * return: doesn't return anything 
		 */
		
		public Car(String make, int year, int price) {
			this.make = make;
			this.year = year;
			this.price = price;
		}
		/*<the method getMake just returns the string make which would be the model of the cars such as , BMW or ford.>
		 * CSC 1351 Programing Project <1>
		 * Section 2 
		 * 
		 * @Richard Le
		 * @March 17, 2024
		 * 
		 * methodname- getMake
		 * parameter: noen
		 * return: returns the make value, which is the type of car in the list for example: "Ford"
		 */
		public String getMake() {
			return make;
		}
		/*<The method getYear returns the int number of the year of the car such like 2016 or 1994 >
		 * CSC 1351 Programing Project <1>
		 * Section 2 
		 * 
		 * @Richard Le
		 * @March 17, 2024
		 * 
		 * methodname-getYear
		 * parameter: none
		 * return the make of the cars year, for example: "2016"
		 */
		public int getYear() {
			return year;
		}
		/*<The method getPrice returns the int number of the price of the mkae of the car such it was would numbers like 32100 or 14500 depending on the price of car>
		 * CSC 1351 Programing Project <1>
		 * Section 2 
		 * 
		 * @Richard Le
		 * @March 17, 2024
		 * 
		 * methodname- getPrice
		 * parameter- none
		 * returns the price of the car for example it would be: "4200"
		 */
		public int getPrice() {
			return price;
		}
		/*<MIn this compareTo method it takes another (Car) object and (other) as parameter, it then compares the make of the current car and the make of the other using the compareTo method, and if the reuslts of the make between the car and other car is different it returns the result of the comparison , but if the makes are equal to one another, it will repeat the same compareTo method but with year instead.It will return a negative integer if "this" object is less than "other" object. Returns 0 if they equal one another and a return a positive integer if this object is greater than other.>
		 * CSC 1351 Programing Project <1>
		 * Section 2 
		 * 
		 * @Richard Le
		 * @March 17, 2024
		 * 
		 * methodname- compareTo
		 * Parameter- Car other
		 * returns: The method is used to determineed the order of car list, such that returning the make.compareTo will put the order in alphabetical order and return Intger.compare will be the years in numerical oreder if the make model equals the same values.  
		 */
		@Override
		public int compareTo(Car other) { 
			int carcomparison;		
			if (make.compareTo(other.make) !=0) {
				return make.compareTo( other.make);
			}
			else  {
					return Integer.compare(year, other.year);
				}			
			}		
		/*<The method toString returns a string that represent the "Car" object, so the following variables needed was the "make", "year", and "price" and it returns the format:  return "Make: " + make + ", Year: " + year + ", Price: " + price;, and for example it would return: "[Make: BMW, Year: 2008, Price: 32100]" >
		 * CSC 1351 Programing Project <1>
		 * Section 2 
		 * 
		 * @Richard Le
		 * @March 17, 2024
		 * 
		 * methodname- toString
		 * parameter- none
		 * returns: this method returns the line of the Make, year and model, for example it would return " Make: Ford, Year: 2016, Price: 4200"
		 */
		@Override
		public String toString() {
		    return "Make: " + make + ", Year: " + year + ", Price: " + price;
		}
	}

